﻿namespace Cosmetics.Common
{
    public enum GenderType
    {
        Men,
        Women,
        Unisex
    }
}
